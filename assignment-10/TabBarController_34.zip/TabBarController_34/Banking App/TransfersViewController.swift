//
//  TransfersViewController.swift
//  Banking App
//
//  Created by Apple Lab 29 on 16/04/25.
//
import UIKit

import Foundation
class TransfersViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Transfers"

        let infoLabel = UILabel()
        infoLabel.text = "This will eventually happen"
        infoLabel.font = UIFont.systemFont(ofSize: 18)
        infoLabel.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(infoLabel)
        NSLayoutConstraint.activate([
            infoLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            infoLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }
}
