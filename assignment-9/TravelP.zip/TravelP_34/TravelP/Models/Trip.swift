//
//  Trip.swift
//  TravelP
//
//  Created by Apple Lab 24 on 16/04/25.
//

import Foundation

struct Trip {
    var destination: String
    var notes: String
}
