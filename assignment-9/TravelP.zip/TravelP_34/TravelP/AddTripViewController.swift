//
//  AddTripViewController.swift
//  TravelP
//
//  Created by Apple Lab 24 on 16/04/25.
//
import UIKit

class AddTripViewController: UIViewController {

    @IBOutlet weak var destinationField: UITextField!
    @IBOutlet weak var notesTextView: UITextView!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    var onTripAdded: ((Trip) -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Add Trip"
    }

    @IBAction func saveTrip(_ sender: UIButton) {
        guard let destination = destinationField.text, !destination.isEmpty else { return }
        
        let trip = Trip(destination: destination,
            notes: notesTextView.text)
        onTripAdded?(trip)
        navigationController?.popViewController(animated: true)
        performSegue(withIdentifier: "showTripList", sender: self)
    }
}

