//
//  TripListViewController.swift
//  TravelP
//
//  Created by Apple Lab 24 on 16/04/25.
//

import UIKit

class TripListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!

    var trips: [Trip] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Trip List"
        tableView.delegate = self
        tableView.dataSource = self
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showTripDetail",
           let detailVC = segue.destination as? TripDetailViewController,
           let index = tableView.indexPathForSelectedRow?.row {
            detailVC.trip = trips[index]
        }
    }

    
    // MARK: - TableView Methods

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return trips.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TripCell", for: indexPath)
        let trip = trips[indexPath.row]
        cell.textLabel?.text = trip.destination
        return cell
    }
}
