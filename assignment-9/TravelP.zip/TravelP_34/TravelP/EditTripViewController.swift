//
//  EditTripViewController.swift
//  TravelP
//
//  Created by Apple Lab 24 on 16/04/25.
//

import UIKit

class EditTripViewController: UIViewController {

    var trip: Trip?

    @IBOutlet weak var destinationField: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var notesTextView: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Edit Trip"
        setupUI()
    }

    func setupUI() {
        destinationField.text = trip?.destination
        notesTextView.text = trip?.notes
    }

    @IBAction func saveChanges(_ sender: UIButton) {
        // Normally here you’d update the trip and notify previous VC
        navigationController?.popViewController(animated: true)
    }
}
