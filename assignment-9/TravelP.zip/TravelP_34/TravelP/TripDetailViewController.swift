//
//  TripDetailViewController.swift
//  TravelP
//
//  Created by Apple Lab 24 on 16/04/25.
//

import UIKit

class TripDetailViewController: UIViewController {

    var trip: Trip?

    @IBOutlet weak var destinationLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var notesTextView: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Trip Details"
        setupUI()

        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .edit, target: self, action: #selector(editTrip))
    }

    func setupUI() {
        destinationLabel.text = trip?.destination
        notesTextView.text = trip?.notes

        
    }

    @objc func editTrip() {
        performSegue(withIdentifier: "showEditTrip", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showEditTrip",
           let editVC = segue.destination as? EditTripViewController {
            editVC.trip = trip
        }
    }
}
