//
//  LoginViewController.swift
//  TravelP
//
//  Created by Apple Lab 24 on 16/04/25.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Login"
        passwordField.isSecureTextEntry = true
    }

    @IBAction func loginTapped(_ sender: UIButton) {
        if usernameField.text == "admin" && passwordField.text == "1234" {
            performSegue(withIdentifier: "showAddTrip", sender: self)
        } else {
            let alert = UIAlertController(title: "Error", message: "Invalid credentials", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }
}
